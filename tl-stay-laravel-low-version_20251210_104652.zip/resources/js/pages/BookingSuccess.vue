<template>
  <AppLayout>
    <div class="booking-success bg-gradient-to-br from-primary-50 via-white to-secondary-50 min-h-screen py-8 md:py-12">
      <div class="container mx-auto px-4 max-w-5xl">
        <!-- Success Icon and Header -->
        <div class="text-center mb-10 animate-fade-in">
          <div class="relative inline-block mb-6">
            <div class="absolute inset-0 bg-green-400 rounded-full blur-xl opacity-30 animate-pulse"></div>
            <div
              class="relative w-24 h-24 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center mx-auto shadow-lg transform transition-transform hover:scale-110"
            >
              <CheckCircleIcon class="w-14 h-14 text-white" />
            </div>
          </div>
          <h1 class="text-4xl md:text-5xl font-bold text-secondary mb-3 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Đặt phòng thành công!
          </h1>
          <p class="text-gray-600 text-lg md:text-xl max-w-2xl mx-auto">
            Cảm ơn bạn đã tin tưởng và sử dụng dịch vụ của chúng tôi. Chúng tôi sẽ liên hệ với bạn sớm nhất có thể.
          </p>
        </div>

        <!-- Booking Details Card -->
        <div class="bg-white rounded-2xl shadow-xl p-6 md:p-8 mb-6 border border-gray-100 hover:shadow-2xl transition-shadow duration-300">
          <div class="mb-6">
            <div class="flex items-center justify-between mb-6">
              <h2 class="text-2xl md:text-3xl font-bold text-secondary flex items-center">
                <div class="w-10 h-10 bg-primary-100 rounded-lg flex items-center justify-center mr-3">
                  <DocumentTextIcon class="w-6 h-6 text-primary" />
                </div>
                Thông tin đặt phòng
              </h2>
              <span class="px-4 py-2 bg-green-100 text-green-700 rounded-full text-sm font-semibold">
                Đã thanh toán
              </span>
            </div>
            <div class="border-t border-gray-200 pt-6">
              <div class="grid md:grid-cols-2 gap-6">
                <!-- Left Column -->
                <div class="space-y-5">
                  <div class="bg-gray-50 rounded-xl p-4 hover:bg-gray-100 transition-colors">
                    <p class="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Mã đặt phòng</p>
                    <p class="text-xl font-bold text-primary font-mono">{{ booking.booking_code || `#${booking.id}` }}</p>
                  </div>
                  <div class="bg-gray-50 rounded-xl p-4 hover:bg-gray-100 transition-colors">
                    <p class="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Nhà trọ</p>
                    <p class="text-lg font-semibold text-gray-900 mb-1">{{ booking.house_name }}</p>
                    <p class="text-sm text-gray-600 flex items-center">
                      <span class="mr-1">📍</span>
                      {{ booking.house_address }}
                    </p>
                  </div>
                  <div class="bg-gray-50 rounded-xl p-4 hover:bg-gray-100 transition-colors">
                    <p class="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Phòng</p>
                    <p class="text-lg font-semibold text-gray-900">
                      🏠 Phòng {{ booking.room_number }} - Tầng {{ booking.floor }}
                    </p>
                  </div>
                </div>

                <!-- Right Column -->
                <div class="space-y-5">
                  <div class="bg-blue-50 rounded-xl p-4 hover:bg-blue-100 transition-colors">
                    <p class="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Ngày nhận phòng</p>
                    <p class="text-lg font-semibold text-gray-900 flex items-center">
                      <span class="mr-2">📅</span>
                      {{ formatDate(booking.start_date) }}
                    </p>
                  </div>
                  <div class="bg-orange-50 rounded-xl p-4 hover:bg-orange-100 transition-colors">
                    <p class="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Ngày trả phòng</p>
                    <p class="text-lg font-semibold text-gray-900 flex items-center">
                      <span class="mr-2">📅</span>
                      {{ formatDate(booking.end_date) }}
                    </p>
                  </div>
                  <div class="bg-purple-50 rounded-xl p-4 hover:bg-purple-100 transition-colors">
                    <p class="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Số ngày thuê</p>
                    <p class="text-lg font-semibold text-gray-900">
                      ⏱️ {{ calculateDays(booking.start_date, booking.end_date) }} ngày
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Payment Information -->
          <div class="border-t border-gray-200 pt-6">
            <h3 class="text-xl md:text-2xl font-bold text-secondary mb-5 flex items-center">
              <div class="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center mr-3">
                <span class="text-green-600 text-lg">💳</span>
              </div>
              Thông tin thanh toán
            </h3>
            <div class="bg-gradient-to-br from-primary-50 to-secondary-50 rounded-xl p-6 space-y-4 border border-primary-100">
              <div class="flex justify-between items-center py-2">
                <span class="text-gray-700 font-medium">Tổng tiền phòng:</span>
                <span class="font-semibold text-gray-900 text-lg">
                  {{ formatPrice(booking.total_price + booking.discount_amount) }}
                </span>
              </div>
              <div v-if="booking.discount_amount > 0" class="flex justify-between items-center py-2 bg-green-50 rounded-lg px-4 -mx-4">
                <span class="text-gray-700 font-medium flex items-center">
                  <span class="mr-2">🎉</span>
                  Giảm giá:
                </span>
                <span class="font-bold text-green-600 text-lg">
                  -{{ formatPrice(booking.discount_amount) }}
                </span>
              </div>
              <div class="flex justify-between items-center pt-4 border-t-2 border-primary-200 mt-4">
                <span class="text-xl font-bold text-secondary">Tổng thanh toán:</span>
                <span class="text-3xl font-bold text-primary">
                  {{ formatPrice(booking.total_price) }}
                </span>
              </div>
              <div class="grid md:grid-cols-2 gap-4 mt-6 pt-4 border-t border-primary-200">
                <div class="bg-white rounded-lg p-3">
                  <p class="text-xs text-gray-500 mb-1">Phương thức thanh toán</p>
                  <p class="font-semibold text-gray-900">
                    {{ getPaymentMethodText(booking.payment_method) }}
                  </p>
                </div>
                <div v-if="booking.vnpay_transaction_id" class="bg-white rounded-lg p-3">
                  <p class="text-xs text-gray-500 mb-1">Mã giao dịch</p>
                  <p class="font-mono text-sm text-gray-900 break-all">{{ booking.vnpay_transaction_id }}</p>
                </div>
                <div v-if="booking.paid_at" class="bg-white rounded-lg p-3 md:col-span-2">
                  <p class="text-xs text-gray-500 mb-1">Thời gian thanh toán</p>
                  <p class="font-semibold text-gray-900">{{ formatDateTime(booking.paid_at) }}</p>
                </div>
              </div>
            </div>
          </div>

          <!-- Notes -->
          <div v-if="booking.notes" class="border-t border-gray-200 pt-6 mt-6">
            <h3 class="text-xl font-bold text-secondary mb-4 flex items-center">
              <span class="mr-2">📝</span>
              Ghi chú
            </h3>
            <div class="bg-yellow-50 border-l-4 border-yellow-400 rounded-r-lg p-4">
              <p class="text-gray-700 leading-relaxed">{{ booking.notes }}</p>
            </div>
          </div>
        </div>

        <!-- Contract Signing Status -->
        <div v-if="!booking.contract_signed" class="mb-6 bg-gradient-to-r from-yellow-50 to-orange-50 border-2 border-yellow-300 rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow">
          <div class="flex items-start">
            <div class="w-12 h-12 bg-yellow-400 rounded-full flex items-center justify-center mr-4 flex-shrink-0">
              <InformationCircleIcon class="w-7 h-7 text-yellow-900" />
            </div>
            <div class="flex-1">
              <h3 class="text-xl font-bold text-yellow-900 mb-2">⚠️ Chưa ký hợp đồng</h3>
              <p class="text-yellow-800 text-sm mb-5 leading-relaxed">
                Vui lòng ký hợp đồng để hoàn tất thủ tục. Hợp đồng sẽ có hiệu lực pháp lý sau khi được ký.
              </p>
              <Link
                :href="`/contract/${booking.id}/sign`"
                class="inline-flex items-center px-6 py-3 bg-yellow-500 hover:bg-yellow-600 text-white font-semibold rounded-lg shadow-md hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200"
              >
                <PencilIcon class="w-5 h-5 mr-2" />
                Ký hợp đồng ngay
              </Link>
            </div>
          </div>
        </div>

        <div v-else class="mb-6 bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-300 rounded-xl p-6 shadow-md">
          <div class="flex items-start">
            <div class="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center mr-4 flex-shrink-0">
              <CheckCircleIcon class="w-7 h-7 text-white" />
            </div>
            <div class="flex-1">
              <h3 class="text-xl font-bold text-green-900 mb-2">✅ Đã ký hợp đồng</h3>
              <p class="text-green-800 text-sm leading-relaxed">
                Hợp đồng của bạn đã được ký và có hiệu lực pháp lý.
                <span v-if="booking.signed_at" class="block mt-2 font-semibold">
                  📅 Thời gian ký: {{ formatDateTime(booking.signed_at) }}
                </span>
              </p>
            </div>
          </div>
        </div>

        <!-- Action Buttons -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <a
            :href="`/contract/${booking.id}`"
            target="_blank"
            class="group bg-primary hover:bg-primary-600 text-white font-semibold py-4 px-6 rounded-xl shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-200 flex items-center justify-center"
          >
            <DocumentArrowDownIcon class="w-5 h-5 mr-2 group-hover:animate-bounce" />
            <span class="text-center">{{ booking.contract_signed ? 'Tải hợp đồng đã ký' : 'Tải hợp đồng thuê' }}</span>
          </a>
          <Link
            v-if="!booking.contract_signed"
            :href="`/contract/${booking.id}/sign`"
            class="group bg-white border-2 border-primary text-primary hover:bg-primary hover:text-white font-semibold py-4 px-6 rounded-xl shadow-md hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200 flex items-center justify-center"
          >
            <PencilIcon class="w-5 h-5 mr-2" />
            Ký hợp đồng
          </Link>
          <Link
            href="/history"
            class="group bg-white border-2 border-gray-300 text-gray-700 hover:border-secondary hover:text-secondary font-semibold py-4 px-6 rounded-xl shadow-md hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200 flex items-center justify-center"
          >
            <ClipboardDocumentListIcon class="w-5 h-5 mr-2" />
            Lịch sử thuê
          </Link>
          <Link
            href="/"
            class="group bg-white border-2 border-gray-300 text-gray-700 hover:border-secondary hover:text-secondary font-semibold py-4 px-6 rounded-xl shadow-md hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200 flex items-center justify-center"
          >
            <HomeIcon class="w-5 h-5 mr-2" />
            Trang chủ
          </Link>
        </div>

        <!-- Important Information -->
        <div class="bg-gradient-to-br from-blue-50 to-indigo-50 border-2 border-blue-200 rounded-xl p-6 md:p-8 shadow-lg">
          <div class="flex items-start">
            <div class="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center mr-4 flex-shrink-0">
              <InformationCircleIcon class="w-7 h-7 text-white" />
            </div>
            <div class="flex-1">
              <h3 class="text-xl md:text-2xl font-bold text-blue-900 mb-4">📌 Thông tin quan trọng</h3>
              <ul class="space-y-3 text-blue-800">
                <li class="flex items-start bg-white rounded-lg p-3 shadow-sm">
                  <span class="text-blue-500 font-bold mr-3 mt-0.5">✓</span>
                  <span>
                    Vui lòng đến nhận phòng đúng ngày <strong class="text-blue-900">{{ formatDate(booking.start_date) }}</strong>
                  </span>
                </li>
                <li class="flex items-start bg-white rounded-lg p-3 shadow-sm">
                  <span class="text-blue-500 font-bold mr-3 mt-0.5">✓</span>
                  <span>
                    Mang theo CMND/CCCD và hợp đồng thuê khi đến nhận phòng
                  </span>
                </li>
                <li class="flex items-start bg-white rounded-lg p-3 shadow-sm">
                  <span class="text-blue-500 font-bold mr-3 mt-0.5">✓</span>
                  <span>
                    Nếu có thắc mắc, vui lòng liên hệ với chủ nhà trọ qua thông tin trên hợp đồng
                  </span>
                </li>
                <li class="flex items-start bg-white rounded-lg p-3 shadow-sm">
                  <span class="text-blue-500 font-bold mr-3 mt-0.5">✓</span>
                  <span>
                    Bạn có thể xem và tải hợp đồng thuê bất cứ lúc nào trong lịch sử thuê
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </AppLayout>
</template>

<script setup>
import { computed } from 'vue'
import { Link } from '@inertiajs/vue3'
import AppLayout from '@/layouts/AppLayout.vue'
import {
  CheckCircleIcon,
  DocumentTextIcon,
  DocumentArrowDownIcon,
  ClipboardDocumentListIcon,
  HomeIcon,
  InformationCircleIcon,
  PencilIcon,
} from '@heroicons/vue/24/outline'

const props = defineProps({
  booking: {
    type: Object,
    required: true,
  },
})

const formatPrice = (price) => {
  if (!price && price !== 0) return '0 ₫'
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND',
  }).format(price)
}

const formatDate = (dateString) => {
  if (!dateString) return ''
  const date = new Date(dateString)
  return date.toLocaleDateString('vi-VN', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  })
}

const formatDateTime = (dateTimeString) => {
  if (!dateTimeString) return ''
  const date = new Date(dateTimeString)
  return date.toLocaleString('vi-VN', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}

const calculateDays = (startDate, endDate) => {
  if (!startDate || !endDate) return 0
  const start = new Date(startDate)
  const end = new Date(endDate)
  const diffTime = Math.abs(end - start)
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
  return diffDays + 1 // +1 để bao gồm cả ngày cuối
}

const getPaymentMethodText = (method) => {
  const methods = {
    vnpay: 'VNPay',
    wallet: 'Ví điện tử',
    cash: 'Tiền mặt',
  }
  return methods[method] || method || 'Chưa xác định'
}
</script>

<style scoped>
@keyframes fade-in {
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.animate-fade-in {
  animation: fade-in 0.6s ease-out;
}
</style>
