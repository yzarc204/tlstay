<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word"
    xmlns:dt="uuid:C2F41010-65B3-11d1-A29F-00AA00C14882" xmlns="http://www.w3.org/TR/REC-html40">

<head>
    <meta http-equiv=Content-Type content="text/html; charset=utf-8">
    <meta name=ProgId content=Word.Document>
    <meta name=Generator content="Microsoft Word 14">
    <meta name=Originator content="Microsoft Word 14">
    <title></title>
    <!--[if gte mso 9]><xml><o:DocumentProperties><o:Author>a48888 Nguyễn Thùy Dung</o:Author><o:LastAuthor>rotten</o:LastAuthor><o:Revision>1</o:Revision><o:Pages>1</o:Pages><o:Lines>1</o:Lines><o:Paragraphs>1</o:Paragraphs></o:DocumentProperties><o:CustomDocumentProperties><o:KSOProductBuildVer dt:dt="string" >1033-11.1.0.11723</o:KSOProductBuildVer></o:CustomDocumentProperties></xml><![endif]--><!--[if gte mso 9]><xml><o:OfficeDocumentSettings></o:OfficeDocumentSettings></xml><![endif]--><!--[if gte mso 9]><xml><w:WordDocument><w:BrowserLevel>MicrosoftInternetExplorer4</w:BrowserLevel><w:DisplayHorizontalDrawingGridEvery>0</w:DisplayHorizontalDrawingGridEvery><w:DisplayVerticalDrawingGridEvery>2</w:DisplayVerticalDrawingGridEvery><w:DocumentKind>DocumentNotSpecified</w:DocumentKind><w:DrawingGridVerticalSpacing>7.8 磅</w:DrawingGridVerticalSpacing><w:PunctuationKerning></w:PunctuationKerning><w:View>Web</w:View><w:Compatibility><w:DontGrowAutofit/></w:Compatibility><w:Zoom>0</w:Zoom></w:WordDocument></xml><![endif]--><!--[if gte mso 9]><xml><w:LatentStyles DefLockedState="false"  DefUnhideWhenUsed="true"  DefSemiHidden="true"  DefQFormat="false"  DefPriority="99"  LatentStyleCount="260" >
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Normal" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="heading 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="heading 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="heading 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="heading 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="heading 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="heading 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  QFormat="true"  Name="heading 7" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  QFormat="true"  Name="heading 8" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  QFormat="true"  Name="heading 9" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="index 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="index 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="index 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="index 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="index 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="index 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="index 7" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="index 8" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="index 9" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="toc 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="toc 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="toc 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="toc 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="toc 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="toc 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="toc 7" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="toc 8" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="toc 9" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Normal Indent" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="footnote text" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="annotation text" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="header" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="footer" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="index heading" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  QFormat="true"  Name="caption" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="table of figures" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="envelope address" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="envelope return" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="footnote reference" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="annotation reference" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="line number" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="page number" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="endnote reference" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="endnote text" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="table of authorities" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="macro" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="toa heading" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="List" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="List Bullet" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="List Number" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="List 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="List 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="List 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="List 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="List Bullet 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="List Bullet 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="List Bullet 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="List Bullet 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="List Number 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="List Number 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="List Number 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="List Number 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Title" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Closing" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Signature" ></w:LsdException>
<w:LsdException Locked="false"  Priority="1"  SemiHidden="false"  Name="Default Paragraph Font" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Body Text" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Body Text Indent" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="List Continue" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="List Continue 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="List Continue 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="List Continue 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="List Continue 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Message Header" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Subtitle" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Salutation" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Date" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Body Text First Indent" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Body Text First Indent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Note Heading" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Body Text 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Body Text 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Body Text Indent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Body Text Indent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Block Text" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Hyperlink" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="FollowedHyperlink" ></w:LsdException>
<w:LsdException Locked="false"  Priority="22"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="Strong" ></w:LsdException>
<w:LsdException Locked="false"  Priority="20"  SemiHidden="false"  UnhideWhenUsed="false"  QFormat="true"  Name="Emphasis" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Document Map" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Plain Text" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="E-mail Signature" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Normal (Web)" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="HTML Acronym" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="HTML Address" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="HTML Cite" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="HTML Code" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="HTML Definition" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="HTML Keyboard" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="HTML Preformatted" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="HTML Sample" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="HTML Typewriter" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="HTML Variable" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Normal Table" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="annotation subject" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="No List" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="1 / a / i" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="1 / 1.1 / 1.1.1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Article / Section" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Simple 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Simple 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Simple 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Classic 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Classic 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Classic 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Classic 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Colorful 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Colorful 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Colorful 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Columns 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Columns 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Columns 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Columns 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Columns 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Grid 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Grid 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Grid 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Grid 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Grid 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Grid 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Grid 7" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Grid 8" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table List 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table List 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table List 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table List 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table List 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table List 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table List 7" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table List 8" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table 3D effects 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table 3D effects 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table 3D effects 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Contemporary" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Elegant" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Professional" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Subtle 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Subtle 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Web 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Web 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Web 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Balloon Text" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Grid" ></w:LsdException>
<w:LsdException Locked="false"  Priority="0"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Table Theme" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Placeholder Text" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="No Spacing" ></w:LsdException>
<w:LsdException Locked="false"  Priority="60"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Shading" ></w:LsdException>
<w:LsdException Locked="false"  Priority="61"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light List" ></w:LsdException>
<w:LsdException Locked="false"  Priority="62"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Grid" ></w:LsdException>
<w:LsdException Locked="false"  Priority="63"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="64"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="65"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="66"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="67"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="68"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="69"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="70"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Dark List" ></w:LsdException>
<w:LsdException Locked="false"  Priority="71"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Shading" ></w:LsdException>
<w:LsdException Locked="false"  Priority="72"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful List" ></w:LsdException>
<w:LsdException Locked="false"  Priority="73"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Grid" ></w:LsdException>
<w:LsdException Locked="false"  Priority="60"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Shading Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="61"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light List Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="62"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Grid Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="63"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 1 Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="64"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 2 Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="65"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 1 Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="List Paragraph" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Quote" ></w:LsdException>
<w:LsdException Locked="false"  Priority="99"  SemiHidden="false"  Name="Intense Quote" ></w:LsdException>
<w:LsdException Locked="false"  Priority="66"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 2 Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="67"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 1 Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="68"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 2 Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="69"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 3 Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="70"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Dark List Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="71"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Shading Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="72"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful List Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="73"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Grid Accent 1" ></w:LsdException>
<w:LsdException Locked="false"  Priority="60"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Shading Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="61"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light List Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="62"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Grid Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="63"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 1 Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="64"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 2 Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="65"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 1 Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="66"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 2 Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="67"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 1 Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="68"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 2 Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="69"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 3 Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="70"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Dark List Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="71"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Shading Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="72"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful List Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="73"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Grid Accent 2" ></w:LsdException>
<w:LsdException Locked="false"  Priority="60"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Shading Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="61"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light List Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="62"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Grid Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="63"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 1 Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="64"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 2 Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="65"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 1 Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="66"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 2 Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="67"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 1 Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="68"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 2 Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="69"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 3 Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="70"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Dark List Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="71"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Shading Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="72"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful List Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="73"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Grid Accent 3" ></w:LsdException>
<w:LsdException Locked="false"  Priority="60"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Shading Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="61"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light List Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="62"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Grid Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="63"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 1 Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="64"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 2 Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="65"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 1 Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="66"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 2 Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="67"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 1 Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="68"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 2 Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="69"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 3 Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="70"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Dark List Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="71"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Shading Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="72"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful List Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="73"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Grid Accent 4" ></w:LsdException>
<w:LsdException Locked="false"  Priority="60"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Shading Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="61"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light List Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="62"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Grid Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="63"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 1 Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="64"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 2 Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="65"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 1 Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="66"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 2 Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="67"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 1 Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="68"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 2 Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="69"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 3 Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="70"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Dark List Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="71"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Shading Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="72"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful List Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="73"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Grid Accent 5" ></w:LsdException>
<w:LsdException Locked="false"  Priority="60"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Shading Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="61"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light List Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="62"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Light Grid Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="63"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 1 Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="64"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Shading 2 Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="65"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 1 Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="66"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium List 2 Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="67"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 1 Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="68"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 2 Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="69"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Medium Grid 3 Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="70"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Dark List Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="71"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Shading Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="72"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful List Accent 6" ></w:LsdException>
<w:LsdException Locked="false"  Priority="73"  SemiHidden="false"  UnhideWhenUsed="false"  Name="Colorful Grid Accent 6" ></w:LsdException>
</w:LatentStyles></xml><![endif]-->
    <style>
        @font-face {
            font-family: "Times New Roman";
        }

        @font-face {
            font-family: "宋体";
        }

        @font-face {
            font-family: "Aptos";
        }

        @font-face {
            font-family: "等线";
        }

        @font-face {
            font-family: "Wingdings";
        }

        @font-face {
            font-family: "Noto Sans Symbols";
        }

        @font-face {
            font-family: "Courier New";
        }

        @font-face {
            font-family: "等线 Light";
        }

        @font-face {
            font-family: "Aptos Display";
        }

        @font-face {
            font-family: "Georgia";
        }

        @font-face {
            font-family: "Arial";
        }

        @list l0:level1 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "●";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 36.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l0:level2 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "o";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 72.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Courier New';
            font-size: 10.0000pt;
        }

        @list l0:level3 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 108.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l0:level4 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 144.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l0:level5 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 180.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l0:level6 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 216.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l0:level7 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 252.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l0:level8 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 288.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l0:level9 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 324.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l1:level1 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "●";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 36.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l1:level2 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "o";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 72.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Courier New';
            font-size: 10.0000pt;
        }

        @list l1:level3 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 108.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l1:level4 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 144.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l1:level5 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 180.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l1:level6 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 216.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l1:level7 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 252.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l1:level8 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 288.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l1:level9 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 324.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l2:level1 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "●";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 36.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l2:level2 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "o";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 72.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Courier New';
            font-size: 10.0000pt;
        }

        @list l2:level3 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 108.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l2:level4 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 144.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l2:level5 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 180.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l2:level6 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 216.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l2:level7 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 252.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l2:level8 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 288.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l2:level9 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 324.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l3:level1 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "●";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 36.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l3:level2 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "o";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 72.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Courier New';
            font-size: 10.0000pt;
        }

        @list l3:level3 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 108.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l3:level4 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 144.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l3:level5 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 180.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l3:level6 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 216.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l3:level7 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 252.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l3:level8 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 288.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l3:level9 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 324.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l4:level1 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "●";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 36.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l4:level2 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "o";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 72.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Courier New';
            font-size: 10.0000pt;
        }

        @list l4:level3 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 108.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l4:level4 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 144.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l4:level5 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 180.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l4:level6 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 216.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l4:level7 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 252.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l4:level8 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 288.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l4:level9 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 324.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l5:level1 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "●";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 36.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l5:level2 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "o";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 72.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Courier New';
            font-size: 10.0000pt;
        }

        @list l5:level3 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 108.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l5:level4 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 144.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l5:level5 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 180.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l5:level6 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 216.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l5:level7 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 252.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l5:level8 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 288.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l5:level9 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 324.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l6:level1 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "●";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 36.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l6:level2 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "o";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 72.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Courier New';
            font-size: 10.0000pt;
        }

        @list l6:level3 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 108.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l6:level4 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 144.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l6:level5 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 180.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l6:level6 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 216.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l6:level7 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 252.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l6:level8 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 288.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l6:level9 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 324.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l7:level1 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "●";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 36.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l7:level2 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "o";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 72.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Courier New';
            font-size: 10.0000pt;
        }

        @list l7:level3 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 108.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l7:level4 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 144.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l7:level5 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 180.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l7:level6 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 216.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l7:level7 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 252.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l7:level8 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 288.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        @list l7:level9 {
            mso-level-number-format: bullet;
            mso-level-suffix: tab;
            mso-level-text: "▪";
            mso-level-tab-stop: none;
            mso-level-number-position: left;
            margin-left: 324.0000pt;
            text-indent: -18.0000pt;
            font-family: 'Noto Sans Symbols';
            font-size: 10.0000pt;
        }

        p.MsoNormal {
            mso-style-name: Normal;
            mso-style-parent: "";
            margin: 0pt;
            margin-bottom: .0001pt;
            font-family: Aptos;
            font-size: 12.0000pt;
        }

        h1 {
            mso-style-name: "Heading 1";
            mso-style-next: Normal;
            margin-top: 15.0000pt;
            margin-bottom: 15.0000pt;
            text-align: center;
            font-family: Aptos;
            color: rgb(0, 83, 156);
            font-weight: bold;
            font-size: 24.0000pt;
        }

        h2 {
            mso-style-name: "Heading 2";
            mso-style-next: Normal;
            margin-top: 22.5000pt;
            font-family: Aptos;
            color: rgb(0, 83, 156);
            font-weight: bold;
            font-size: 18.0000pt;
        }

        h3 {
            mso-style-name: "Heading 3";
            mso-style-next: Normal;
            margin: 0pt;
            margin-bottom: .0001pt;
            font-family: Aptos;
            font-weight: bold;
            font-size: 13.5000pt;
        }

        h4 {
            mso-style-name: "Heading 4";
            mso-style-next: Normal;
            margin-top: 12.0000pt;
            margin-bottom: 2.0000pt;
            page-break-after: avoid;
            mso-pagination: lines-together;
            font-family: Aptos;
            font-weight: bold;
            font-size: 12.0000pt;
        }

        h5 {
            mso-style-name: "Heading 5";
            mso-style-next: Normal;
            margin-top: 11.0000pt;
            margin-bottom: 2.0000pt;
            page-break-after: avoid;
            mso-pagination: lines-together;
            font-family: Aptos;
            font-weight: bold;
            font-size: 11.0000pt;
        }

        h6 {
            mso-style-name: "Heading 6";
            mso-style-next: Normal;
            margin-top: 10.0000pt;
            margin-bottom: 2.0000pt;
            page-break-after: avoid;
            mso-pagination: lines-together;
            font-family: Aptos;
            font-weight: bold;
            font-size: 10.0000pt;
        }

        span.10 {
            font-family: Aptos;
        }

        span.15 {
            font-family: Aptos;
            mso-fareast-font-family: '等线 Light';
            mso-bidi-font-family: 'Times New Roman';
            color: rgb(15, 71, 97);
            font-size: 14.0000pt;
        }

        span.16 {
            font-family: 'Aptos Display';
            mso-fareast-font-family: '等线 Light';
            mso-bidi-font-family: 'Times New Roman';
            color: rgb(15, 71, 97);
            font-size: 20.0000pt;
        }

        span.17 {
            font-family: 'Aptos Display';
            mso-fareast-font-family: '等线 Light';
            mso-bidi-font-family: 'Times New Roman';
            color: rgb(15, 71, 97);
            font-size: 16.0000pt;
        }

        span.18 {
            font-family: Aptos;
            font-weight: bold;
        }

        span.19 {
            font-family: Aptos;
            font-style: italic;
        }

        p.MsoSubtitle {
            mso-style-name: Subtitle;
            mso-style-next: Normal;
            margin-top: 18.0000pt;
            margin-bottom: 4.0000pt;
            page-break-after: avoid;
            mso-pagination: lines-together;
            font-family: Georgia;
            color: rgb(102, 102, 102);
            font-style: italic;
            font-size: 24.0000pt;
        }

        p.21 {
            mso-style-name: footer-sign;
            margin-top: 37.5000pt;
            margin-bottom: 5.0000pt;
            mso-margin-bottom-alt: auto;
            vertical-align: top;
            font-family: Aptos;
            font-size: 10.5000pt;
        }

        p.MsoTitle {
            mso-style-name: Title;
            mso-style-next: Normal;
            margin-top: 24.0000pt;
            margin-bottom: 6.0000pt;
            page-break-after: avoid;
            mso-pagination: lines-together;
            font-family: Aptos;
            font-weight: bold;
            font-size: 36.0000pt;
        }

        p.p {
            mso-style-name: "Normal \(Web\)";
            mso-style-noshow: yes;
            margin-top: 5.0000pt;
            margin-bottom: 5.0000pt;
            mso-margin-top-alt: auto;
            mso-margin-bottom-alt: auto;
            font-family: Aptos;
            font-size: 10.5000pt;
        }

        p.24 {
            mso-style-name: text-center;
            margin-top: 5.0000pt;
            margin-bottom: 5.0000pt;
            mso-margin-top-alt: auto;
            mso-margin-bottom-alt: auto;
            text-align: center;
            font-family: Aptos;
            font-size: 10.5000pt;
        }

        p.25 {
            mso-style-name: text-right;
            margin-top: 5.0000pt;
            margin-bottom: 5.0000pt;
            mso-margin-top-alt: auto;
            mso-margin-bottom-alt: auto;
            text-align: right;
            font-family: Aptos;
            font-size: 10.5000pt;
        }

        p.26 {
            mso-style-name: msonormal;
            margin-top: 5.0000pt;
            margin-bottom: 5.0000pt;
            mso-margin-top-alt: auto;
            mso-margin-bottom-alt: auto;
            font-family: Aptos;
            font-size: 10.5000pt;
        }

        span.msoIns {
            mso-style-type: export-only;
            mso-style-name: "";
            text-decoration: underline;
            text-underline: single;
            color: blue;
        }

        span.msoDel {
            mso-style-type: export-only;
            mso-style-name: "";
            text-decoration: line-through;
            color: red;
        }

        table.MsoNormalTable {
            mso-style-name: "Table Normal";
            mso-style-parent: "";
            mso-style-noshow: yes;
            mso-tstyle-rowband-size: 0;
            mso-tstyle-colband-size: 0;
            mso-padding-alt: 0.0000pt 5.4000pt 0.0000pt 5.4000pt;
            mso-para-margin: 0pt;
            mso-para-margin-bottom: .0001pt;
            mso-pagination: widow-orphan;
            font-family: 'Times New Roman';
            font-size: 10.0000pt;
            mso-ansi-language: #0400;
            mso-fareast-language: #0400;
            mso-bidi-language: #0400;
        }

        table.29 {
            mso-style-name: TableNormal;
            mso-tstyle-rowband-size: 0;
            mso-tstyle-colband-size: 0;
            mso-padding-alt: 5.0000pt 5.0000pt 5.0000pt 5.0000pt;
            mso-para-margin: 0pt;
            mso-para-margin-bottom: .0001pt;
            mso-pagination: widow-orphan;
            font-family: 'Times New Roman';
            font-size: 10.0000pt;
            mso-ansi-language: #0400;
            mso-fareast-language: #0400;
            mso-bidi-language: #0400;
        }

        table.28 {
            mso-style-name: "_Style 22";
            mso-style-parent: TableNormal;
            mso-tstyle-rowband-size: 0;
            mso-tstyle-colband-size: 0;
            mso-padding-alt: 0.7500pt 0.7500pt 0.7500pt 0.7500pt;
            mso-para-margin: 0pt;
            mso-para-margin-bottom: .0001pt;
            mso-pagination: widow-orphan;
            font-family: 'Times New Roman';
            font-size: 10.0000pt;
            mso-ansi-language: #0400;
            mso-fareast-language: #0400;
            mso-bidi-language: #0400;
        }

        table.27 {
            mso-style-name: "_Style 23";
            mso-style-parent: TableNormal;
            mso-tstyle-rowband-size: 0;
            mso-tstyle-colband-size: 0;
            mso-padding-alt: 0.7500pt 0.7500pt 0.7500pt 0.7500pt;
            mso-para-margin: 0pt;
            mso-para-margin-bottom: .0001pt;
            mso-pagination: widow-orphan;
            font-family: 'Times New Roman';
            font-size: 10.0000pt;
            mso-ansi-language: #0400;
            mso-fareast-language: #0400;
            mso-bidi-language: #0400;
        }

        @page {
            mso-page-border-surround-header: no;
            mso-page-border-surround-footer: no;
        }

        @page Section0 {
            margin-top: 72.0000pt;
            margin-bottom: 72.0000pt;
            margin-left: 72.0000pt;
            margin-right: 72.0000pt;
            size: 612.0000pt 792.0000pt;
            mso-header-margin: 36.0000pt;
            mso-footer-margin: 36.0000pt;
        }

        div.Section0 {
            page: Section0;
        }

        @page Section1 {
            margin-top: 72.0000pt;
            margin-bottom: 72.0000pt;
            margin-left: 72.0000pt;
            margin-right: 72.0000pt;
            size: 612.0000pt 792.0000pt;
            mso-header-margin: 36.0000pt;
            mso-footer-margin: 36.0000pt;
        }

        div.Section1 {
            page: Section1;
        }

        @page Section2 {
            margin-top: 72.0000pt;
            margin-bottom: 72.0000pt;
            margin-left: 72.0000pt;
            margin-right: 72.0000pt;
            size: 612.0000pt 792.0000pt;
            mso-header-margin: 36.0000pt;
            mso-footer-margin: 36.0000pt;
        }

        div.Section2 {
            page: Section2;
        }
    </style>
</head>

<body style="tab-interval:36pt;"><!--StartFragment-->
    <div class="Section0">
        <p class=MsoNormal align=center style="margin-top:0.0000pt;margin-right:0.0000pt;margin-bottom:0.0000pt;
margin-left:0.0000pt;text-indent:0.0000pt;padding:0pt 0pt 0pt 0pt ;
mso-pagination:widow-orphan;text-align:center;"><b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-weight:bold;font-style:normal;font-variant:normal;
font-size:10.5000pt;">C&#7896;NG H&#210;A X&#195; H&#7896;I CH&#7910; NGH&#296;A VI&#7878;T NAM</span></b><span style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-style:normal;font-variant:normal;font-size:10.5000pt;">
                <o:p></o:p>
            </span></p>
        <p class=MsoNormal align=center style="margin-top:0.0000pt;margin-right:0.0000pt;margin-bottom:0.0000pt;
margin-left:0.0000pt;text-indent:0.0000pt;padding:0pt 0pt 0pt 0pt ;
mso-pagination:widow-orphan;text-align:center;"><i><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-style:italic;font-variant:normal;font-size:10.5000pt;">&#272;&#7897;c l&#7853;p - T&#7921; do - H&#7841;nh
                    ph&#250;c</span></i><i><span style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-style:italic;font-variant:normal;font-size:10.5000pt;">
                    <o:p></o:p>
                </span></i></p>
        <p class=MsoNormal align=center style="margin-top:0.0000pt;margin-right:0.0000pt;margin-bottom:0.0000pt;
margin-left:0.0000pt;text-indent:0.0000pt;padding:0pt 0pt 0pt 0pt ;
mso-pagination:widow-orphan;text-align:center;"><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-style:normal;font-variant:normal;font-size:10.5000pt;">**********</span><i><span style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-style:italic;font-variant:normal;font-size:10.5000pt;">
                    <o:p></o:p>
                </span></i></p>
        <p class=MsoNormal align=right style="margin-top:0.0000pt;margin-right:0.0000pt;margin-bottom:0.0000pt;
margin-left:0.0000pt;text-indent:0.0000pt;padding:0pt 0pt 0pt 0pt ;
mso-pagination:widow-orphan;text-align:right;"><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-style:normal;font-variant:normal;font-size:10.5000pt;">{{ $contractPlace }}, ngày {{ $contractDateDay }} tháng
                {{ $contractDateMonth }} năm {{ $contractDateYear }}</span><span style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-style:normal;font-variant:normal;font-size:10.5000pt;">
                <o:p></o:p>
            </span></p>
        <h1><b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(0,83,156);
font-weight:bold;font-size:24.0000pt;">H&#7906;P &#272;&#7890;NG THU&#202; TR&#7884;</span></b><b><span style="mso-spacerun:'yes';font-family:Aptos;color:rgb(0,83,156);
font-weight:bold;font-size:24.0000pt;">
                    <o:p></o:p>
                </span></b></h1>
        <p class=MsoNormal style="margin-top:14.0000pt;margin-bottom:0.0000pt;margin-left:36.0000pt;
text-indent:-18.0000pt;mso-list:l0 level1 lfo1;">
            <![if !supportLists]><span
                style="font-family:'Noto Sans Symbols';color:rgb(51,51,51);font-size:10.0000pt;"><span
                    style='mso-list:Ignore;'>&#9679;<span>&nbsp;</span></span></span>
            <![endif]><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">C&#259;n c&#7913; B&#7897; lu&#7853;t D&#226;n s&#7921; s&#7889; 91/2015/QH13 ng&#224;y
                24/11/2015;</span><span style="mso-spacerun:'yes';font-family:'Times New Roman';color:rgb(51,51,51);
font-size:10.5000pt;">
                <o:p></o:p>
            </span>
        </p>
        <p class=MsoNormal style="margin-top:0.0000pt;margin-bottom:0.0000pt;margin-left:36.0000pt;
text-indent:-18.0000pt;mso-list:l0 level1 lfo1;">
            <![if !supportLists]><span
                style="font-family:'Noto Sans Symbols';color:rgb(51,51,51);font-size:10.0000pt;"><span
                    style='mso-list:Ignore;'>&#9679;<span>&nbsp;</span></span></span>
            <![endif]><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">C&#259;n c&#7913; Lu&#7853;t Th&#432;&#417;ng m&#7841;i s&#7889; 36/2005/QH11 ng&#224;y
                14/06/2005;</span><span style="mso-spacerun:'yes';font-family:'Times New Roman';color:rgb(51,51,51);
font-size:10.5000pt;">
                <o:p></o:p>
            </span>
        </p>
        <p class=MsoNormal style="margin-top:0.0000pt;margin-bottom:14.0000pt;margin-left:36.0000pt;
text-indent:-18.0000pt;mso-list:l0 level1 lfo1;">
            <![if !supportLists]><span
                style="font-family:'Noto Sans Symbols';color:rgb(51,51,51);font-size:10.0000pt;"><span
                    style='mso-list:Ignore;'>&#9679;<span>&nbsp;</span></span></span>
            <![endif]><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">C&#259;n c&#7913; v&#224;o nhu c&#7847;u v&#224; s&#7921; th&#7887;a thu&#7853;n c&#7911;a
                c&#225;c B&#234;n;</span><span style="mso-spacerun:'yes';font-family:'Times New Roman';color:rgb(51,51,51);
font-size:10.5000pt;">
                <o:p></o:p>
            </span>
        </p>
        <p class=MsoNormal style="margin-top:0.0000pt;margin-right:0.0000pt;margin-bottom:0.0000pt;
margin-left:0.0000pt;text-indent:0.0000pt;padding:0pt 0pt 0pt 0pt ;
mso-pagination:widow-orphan;text-align:left;"><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-style:normal;font-variant:normal;font-size:10.5000pt;">H&#244;m nay, ng&#224;y </span><b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-weight:bold;font-style:normal;font-variant:normal;
font-size:10.5000pt;">
                    <font face="Aptos">{{ $contractDateDay }}/{{ $contractDateMonth }}/{{ $contractDateYear }}</font>
                </span></b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-style:normal;font-variant:normal;font-size:10.5000pt;">&nbsp;t&#7841;i </span><b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-weight:bold;font-style:normal;font-variant:normal;
font-size:10.5000pt;">
                    <font face="Aptos">{{ $contractPlace }}</font>
                </span></b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-style:normal;font-variant:normal;font-size:10.5000pt;">, ch&#250;ng t&#244;i g&#7891;m:</span><span style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-style:normal;font-variant:normal;font-size:10.5000pt;">
                <o:p></o:p>
            </span></p>
        <h2><b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(0,83,156);
font-weight:bold;font-size:18.0000pt;">B&#202;N A (Doanh nghi&#7879;p/C&#244;ng ty cho thu&#234;)</span></b><b><span
                    style="mso-spacerun:'yes';font-family:Aptos;color:rgb(0,83,156);
font-weight:bold;font-size:18.0000pt;">
                    <o:p></o:p>
                </span></b></h2>
        <table class=28 border=1 cellspacing=0 style="border-collapse:collapse;width:467.2000pt;margin-left:-0.6000pt;
mso-table-layout-alt:fixed;border:none;mso-border-left-alt:0.7500pt solid rgb(102,102,102);
mso-border-top-alt:0.7500pt solid rgb(102,102,102);mso-border-right-alt:0.7500pt solid rgb(102,102,102);mso-border-bottom-alt:0.7500pt solid rgb(102,102,102);
mso-padding-alt:0.7500pt 0.7500pt 0.7500pt 0.7500pt ;">
            <tr>
                <td width=138 valign=center style="width:104.0500pt;padding:6.0000pt 6.0000pt 6.0000pt 6.0000pt ;border-left:1.0000pt solid rgb(102,102,102);
mso-border-left-alt:0.7500pt solid rgb(102,102,102);border-right:1.0000pt solid rgb(102,102,102);mso-border-right-alt:0.7500pt solid rgb(102,102,102);
border-top:1.0000pt solid rgb(102,102,102);mso-border-top-alt:0.7500pt solid rgb(102,102,102);border-bottom:1.0000pt solid rgb(102,102,102);
mso-border-bottom-alt:0.7500pt solid rgb(102,102,102);">
                    <p class=MsoNormal style="margin-top:7.5000pt;margin-bottom:7.5000pt;"><b><span dir="LTR" style="font-family:Aptos;color:rgb(51,51,51);font-weight:bold;
font-size:12.0000pt;">T&#234;n c&#244;ng ty</span></b><b><span style="font-family:Aptos;color:rgb(51,51,51);font-weight:bold;
font-size:12.0000pt;">
                                <o:p></o:p>
                            </span></b></p>
                </td>
                <td width=484 valign=center style="width:363.1500pt;padding:6.0000pt 6.0000pt 6.0000pt 6.0000pt ;border-left:none;
mso-border-left-alt:none;border-right:1.0000pt solid rgb(102,102,102);mso-border-right-alt:0.7500pt solid rgb(102,102,102);
border-top:1.0000pt solid rgb(102,102,102);mso-border-top-alt:0.7500pt solid rgb(102,102,102);border-bottom:1.0000pt solid rgb(102,102,102);
mso-border-bottom-alt:0.7500pt solid rgb(102,102,102);">
                    <p class=MsoNormal style="margin-top:7.5000pt;margin-bottom:7.5000pt;"><span dir="LTR"
                            style="font-family:Aptos;color:rgb(51,51,51);font-size:12.0000pt;">{{ $companyName }}</span><span
                            style="font-family:Aptos;color:rgb(51,51,51);font-size:12.0000pt;">
                            <o:p></o:p>
                        </span></p>
                </td>
            </tr>
            <tr>
                <td width=138 valign=center style="width:104.0500pt;padding:6.0000pt 6.0000pt 6.0000pt 6.0000pt ;border-left:1.0000pt solid rgb(102,102,102);
mso-border-left-alt:0.7500pt solid rgb(102,102,102);border-right:1.0000pt solid rgb(102,102,102);mso-border-right-alt:0.7500pt solid rgb(102,102,102);
border-top:none;mso-border-top-alt:0.7500pt solid rgb(102,102,102);border-bottom:1.0000pt solid rgb(102,102,102);
mso-border-bottom-alt:0.7500pt solid rgb(102,102,102);">
                    <p class=MsoNormal style="margin-top:7.5000pt;margin-bottom:7.5000pt;"><b><span dir="LTR" style="font-family:Aptos;color:rgb(51,51,51);font-weight:bold;
font-size:12.0000pt;">M&#227; s&#7889; doanh nghi&#7879;p</span></b><b><span style="font-family:Aptos;color:rgb(51,51,51);font-weight:bold;
font-size:12.0000pt;">
                                <o:p></o:p>
                            </span></b></p>
                </td>
                <td width=484 valign=center style="width:363.1500pt;padding:6.0000pt 6.0000pt 6.0000pt 6.0000pt ;border-left:none;
mso-border-left-alt:none;border-right:1.0000pt solid rgb(102,102,102);mso-border-right-alt:0.7500pt solid rgb(102,102,102);
border-top:none;mso-border-top-alt:0.7500pt solid rgb(102,102,102);border-bottom:1.0000pt solid rgb(102,102,102);
mso-border-bottom-alt:0.7500pt solid rgb(102,102,102);">
                    <p class=MsoNormal style="margin-top:7.5000pt;margin-bottom:7.5000pt;"><span dir="LTR"
                            style="font-family:Aptos;color:rgb(51,51,51);font-size:12.0000pt;">{{ $companyTaxCode }}
                            <span style="mso-spacerun:'yes';">&nbsp;</span></span><span
                            style="font-family:Aptos;color:rgb(51,51,51);font-size:12.0000pt;">
                            <o:p></o:p>
                        </span></p>
                    <p class=MsoNormal style="margin-top:7.5000pt;margin-bottom:7.5000pt;"><span dir="LTR"
                            style="font-family:Aptos;color:rgb(51,51,51);font-size:12.0000pt;">C&#7845;p ng&#224;y:
                            {{ $companyTaxCodeIssueDate }} </span><span
                            style="font-family:Aptos;color:rgb(51,51,51);font-size:12.0000pt;">
                            <o:p></o:p>
                        </span></p>
                    <p class=MsoNormal style="margin-top:7.5000pt;margin-bottom:7.5000pt;"><span dir="LTR"
                            style="font-family:Aptos;color:rgb(51,51,51);font-size:12.0000pt;">N&#417;i c&#7845;p:
                            {{ $companyTaxCodeIssuePlace }}</span><span
                            style="font-family:Aptos;color:rgb(51,51,51);font-size:12.0000pt;">
                            <o:p></o:p>
                        </span></p>
                </td>
            </tr>
            <tr>
                <td width=138 valign=center style="width:104.0500pt;padding:6.0000pt 6.0000pt 6.0000pt 6.0000pt ;border-left:1.0000pt solid rgb(102,102,102);
mso-border-left-alt:0.7500pt solid rgb(102,102,102);border-right:1.0000pt solid rgb(102,102,102);mso-border-right-alt:0.7500pt solid rgb(102,102,102);
border-top:none;mso-border-top-alt:0.7500pt solid rgb(102,102,102);border-bottom:1.0000pt solid rgb(102,102,102);
mso-border-bottom-alt:0.7500pt solid rgb(102,102,102);">
                    <p class=MsoNormal style="margin-top:7.5000pt;margin-bottom:7.5000pt;"><b><span dir="LTR" style="font-family:Aptos;color:rgb(51,51,51);font-weight:bold;
font-size:12.0000pt;">&#272;&#7883;a ch&#7881; tr&#7909; s&#7903; ch&#237;nh</span></b><b><span style="font-family:Aptos;color:rgb(51,51,51);font-weight:bold;
font-size:12.0000pt;">
                                <o:p></o:p>
                            </span></b></p>
                </td>
                <td width=484 valign=center style="width:363.1500pt;padding:6.0000pt 6.0000pt 6.0000pt 6.0000pt ;border-left:none;
mso-border-left-alt:none;border-right:1.0000pt solid rgb(102,102,102);mso-border-right-alt:0.7500pt solid rgb(102,102,102);
border-top:none;mso-border-top-alt:0.7500pt solid rgb(102,102,102);border-bottom:1.0000pt solid rgb(102,102,102);
mso-border-bottom-alt:0.7500pt solid rgb(102,102,102);">
                    <p class=MsoNormal style="margin-top:7.5000pt;margin-bottom:7.5000pt;"><span dir="LTR"
                            style="font-family:Aptos;color:rgb(51,51,51);font-size:12.0000pt;">{{ $companyAddress }}</span><span
                            style="font-family:Aptos;color:rgb(51,51,51);font-size:12.0000pt;">
                            <o:p></o:p>
                        </span></p>
                </td>
            </tr>
            <tr>
                <td width=138 valign=center style="width:104.0500pt;padding:6.0000pt 6.0000pt 6.0000pt 6.0000pt ;border-left:1.0000pt solid rgb(102,102,102);
mso-border-left-alt:0.7500pt solid rgb(102,102,102);border-right:1.0000pt solid rgb(102,102,102);mso-border-right-alt:0.7500pt solid rgb(102,102,102);
border-top:none;mso-border-top-alt:0.7500pt solid rgb(102,102,102);border-bottom:1.0000pt solid rgb(102,102,102);
mso-border-bottom-alt:0.7500pt solid rgb(102,102,102);">
                    <p class=MsoNormal style="margin-top:7.5000pt;margin-bottom:7.5000pt;"><b><span dir="LTR" style="font-family:Aptos;color:rgb(51,51,51);font-weight:bold;
font-size:12.0000pt;">&#272;&#7841;i di&#7879;n</span></b><b><span style="font-family:Aptos;color:rgb(51,51,51);font-weight:bold;
font-size:12.0000pt;">
                                <o:p></o:p>
                            </span></b></p>
                </td>
                <td width=484 valign=center style="width:363.1500pt;padding:6.0000pt 6.0000pt 6.0000pt 6.0000pt ;border-left:none;
mso-border-left-alt:none;border-right:1.0000pt solid rgb(102,102,102);mso-border-right-alt:0.7500pt solid rgb(102,102,102);
border-top:none;mso-border-top-alt:0.7500pt solid rgb(102,102,102);border-bottom:1.0000pt solid rgb(102,102,102);
mso-border-bottom-alt:0.7500pt solid rgb(102,102,102);">
                    <p class=MsoNormal style="margin-top:7.5000pt;margin-bottom:7.5000pt;"><span dir="LTR"
                            style="font-family:Aptos;color:rgb(51,51,51);font-size:12.0000pt;">H&#7885; v&#224;
                            t&#234;n: {{ $companyRepresentativeName }} – Ch&#7913;c v&#7909;:
                            {{ $companyRepresentativePosition }}</span><span
                            style="font-family:Aptos;color:rgb(51,51,51);font-size:12.0000pt;">
                            <o:p></o:p>
                        </span></p>
                </td>
            </tr>
            <tr>
                <td width=138 valign=center style="width:104.0500pt;padding:6.0000pt 6.0000pt 6.0000pt 6.0000pt ;border-left:1.0000pt solid rgb(102,102,102);
mso-border-left-alt:0.7500pt solid rgb(102,102,102);border-right:1.0000pt solid rgb(102,102,102);mso-border-right-alt:0.7500pt solid rgb(102,102,102);
border-top:none;mso-border-top-alt:0.7500pt solid rgb(102,102,102);border-bottom:1.0000pt solid rgb(102,102,102);
mso-border-bottom-alt:0.7500pt solid rgb(102,102,102);">
                    <p class=MsoNormal style="margin-top:7.5000pt;margin-bottom:7.5000pt;"><b><span dir="LTR" style="font-family:Aptos;color:rgb(51,51,51);font-weight:bold;
font-size:12.0000pt;">&#272;i&#7879;n tho&#7841;i</span></b><b><span style="font-family:Aptos;color:rgb(51,51,51);font-weight:bold;
font-size:12.0000pt;">
                                <o:p></o:p>
                            </span></b></p>
                </td>
                <td width=484 valign=center style="width:363.1500pt;padding:6.0000pt 6.0000pt 6.0000pt 6.0000pt ;border-left:none;
mso-border-left-alt:none;border-right:1.0000pt solid rgb(102,102,102);mso-border-right-alt:0.7500pt solid rgb(102,102,102);
border-top:none;mso-border-top-alt:0.7500pt solid rgb(102,102,102);border-bottom:1.0000pt solid rgb(102,102,102);
mso-border-bottom-alt:0.7500pt solid rgb(102,102,102);">
                    <p class=MsoNormal style="margin-top:7.5000pt;margin-bottom:7.5000pt;"><span dir="LTR"
                            style="font-family:Aptos;color:rgb(51,51,51);font-size:12.0000pt;">{{ $companyPhone }}</span><span
                            style="font-family:Aptos;color:rgb(51,51,51);font-size:12.0000pt;">
                            <o:p></o:p>
                        </span></p>
                </td>
            </tr>
            <tr>
                <td width=138 valign=center style="width:104.0500pt;padding:6.0000pt 6.0000pt 6.0000pt 6.0000pt ;border-left:1.0000pt solid rgb(102,102,102);
mso-border-left-alt:0.7500pt solid rgb(102,102,102);border-right:1.0000pt solid rgb(102,102,102);mso-border-right-alt:0.7500pt solid rgb(102,102,102);
border-top:none;mso-border-top-alt:0.7500pt solid rgb(102,102,102);border-bottom:1.0000pt solid rgb(102,102,102);
mso-border-bottom-alt:0.7500pt solid rgb(102,102,102);">
                    <p class=MsoNormal style="margin-top:7.5000pt;margin-bottom:7.5000pt;"><b><span dir="LTR" style="font-family:Aptos;color:rgb(51,51,51);font-weight:bold;
font-size:12.0000pt;">Email</span></b><b><span style="font-family:Aptos;color:rgb(51,51,51);font-weight:bold;
font-size:12.0000pt;">
                                <o:p></o:p>
                            </span></b></p>
                </td>
                <td width=484 valign=center style="width:363.1500pt;padding:6.0000pt 6.0000pt 6.0000pt 6.0000pt ;border-left:none;
mso-border-left-alt:none;border-right:1.0000pt solid rgb(102,102,102);mso-border-right-alt:0.7500pt solid rgb(102,102,102);
border-top:none;mso-border-top-alt:0.7500pt solid rgb(102,102,102);border-bottom:1.0000pt solid rgb(102,102,102);
mso-border-bottom-alt:0.7500pt solid rgb(102,102,102);">
                    <p class=MsoNormal style="margin-top:7.5000pt;margin-bottom:7.5000pt;"><span dir="LTR"
                            style="font-family:Aptos;color:rgb(51,51,51);font-size:12.0000pt;">{{ $companyEmail }}</span><span
                            style="font-family:Aptos;color:rgb(51,51,51);font-size:12.0000pt;">
                            <o:p></o:p>
                        </span></p>
                </td>
            </tr>
        </table>
        <h2><b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(0,83,156);
font-weight:bold;font-size:18.0000pt;">B&#202;N B (Ng&#432;&#7901;i Thu&#234;)</span></b><b><span style="mso-spacerun:'yes';font-family:Aptos;color:rgb(0,83,156);
font-weight:bold;font-size:18.0000pt;">
                    <o:p></o:p>
                </span></b></h2>
        <table class=27 border=1 cellspacing=0 style="border-collapse:collapse;width:467.2000pt;margin-left:-0.6000pt;
mso-table-layout-alt:fixed;border:none;mso-border-left-alt:0.7500pt solid rgb(102,102,102);
mso-border-top-alt:0.7500pt solid rgb(102,102,102);mso-border-right-alt:0.7500pt solid rgb(102,102,102);mso-border-bottom-alt:0.7500pt solid rgb(102,102,102);
mso-padding-alt:0.7500pt 0.7500pt 0.7500pt 0.7500pt ;">
            <tr>
                <td width=167 valign=center style="width:125.8500pt;padding:6.0000pt 6.0000pt 6.0000pt 6.0000pt ;border-left:1.0000pt solid rgb(102,102,102);
mso-border-left-alt:0.7500pt solid rgb(102,102,102);border-right:1.0000pt solid rgb(102,102,102);mso-border-right-alt:0.7500pt solid rgb(102,102,102);
border-top:1.0000pt solid rgb(102,102,102);mso-border-top-alt:0.7500pt solid rgb(102,102,102);border-bottom:1.0000pt solid rgb(102,102,102);
mso-border-bottom-alt:0.7500pt solid rgb(102,102,102);">
                    <p class=MsoNormal style="margin-top:7.5000pt;margin-bottom:7.5000pt;"><b><span dir="LTR" style="font-family:Aptos;color:rgb(51,51,51);font-weight:bold;
font-size:12.0000pt;">H&#7885; v&#224; t&#234;n</span></b><b><span style="font-family:Aptos;color:rgb(51,51,51);font-weight:bold;
font-size:12.0000pt;">
                                <o:p></o:p>
                            </span></b></p>
                </td>
                <td width=455 valign=center style="width:341.3500pt;padding:6.0000pt 6.0000pt 6.0000pt 6.0000pt ;border-left:none;
mso-border-left-alt:none;border-right:1.0000pt solid rgb(102,102,102);mso-border-right-alt:0.7500pt solid rgb(102,102,102);
border-top:1.0000pt solid rgb(102,102,102);mso-border-top-alt:0.7500pt solid rgb(102,102,102);border-bottom:1.0000pt solid rgb(102,102,102);
mso-border-bottom-alt:0.7500pt solid rgb(102,102,102);">
                    <p class=MsoNormal style="margin-top:7.5000pt;margin-bottom:7.5000pt;"><span dir="LTR"
                            style="font-family:Aptos;color:rgb(51,51,51);font-size:12.0000pt;">
                            <font face="Aptos">{{ $userName }}</font>
                        </span><span style="font-family:Aptos;color:rgb(51,51,51);font-size:12.0000pt;">
                            <o:p></o:p>
                        </span></p>
                </td>
            </tr>
            <tr>
                <td width=167 valign=center style="width:125.8500pt;padding:6.0000pt 6.0000pt 6.0000pt 6.0000pt ;border-left:1.0000pt solid rgb(102,102,102);
mso-border-left-alt:0.7500pt solid rgb(102,102,102);border-right:1.0000pt solid rgb(102,102,102);mso-border-right-alt:0.7500pt solid rgb(102,102,102);
border-top:none;mso-border-top-alt:0.7500pt solid rgb(102,102,102);border-bottom:1.0000pt solid rgb(102,102,102);
mso-border-bottom-alt:0.7500pt solid rgb(102,102,102);">
                    <p class=MsoNormal style="margin-top:7.5000pt;margin-bottom:7.5000pt;"><b><span dir="LTR" style="font-family:Aptos;color:rgb(51,51,51);font-weight:bold;
font-size:12.0000pt;">Sinh n&#259;m</span></b><b><span style="font-family:Aptos;color:rgb(51,51,51);font-weight:bold;
font-size:12.0000pt;">
                                <o:p></o:p>
                            </span></b></p>
                </td>
                <td width=455 valign=center style="width:341.3500pt;padding:6.0000pt 6.0000pt 6.0000pt 6.0000pt ;border-left:none;
mso-border-left-alt:none;border-right:1.0000pt solid rgb(102,102,102);mso-border-right-alt:0.7500pt solid rgb(102,102,102);
border-top:none;mso-border-top-alt:0.7500pt solid rgb(102,102,102);border-bottom:1.0000pt solid rgb(102,102,102);
mso-border-bottom-alt:0.7500pt solid rgb(102,102,102);">
                    <p class=MsoNormal style="margin-top:7.5000pt;margin-bottom:7.5000pt;"><span dir="LTR"
                            style="font-family:Aptos;color:rgb(51,51,51);font-size:12.0000pt;">
                            <font face="Aptos">{{ $userBirthYear }}</font>
                        </span><span style="font-family:Aptos;color:rgb(51,51,51);font-size:12.0000pt;">
                            <o:p></o:p>
                        </span></p>
                </td>
            </tr>
            <tr>
                <td width=167 valign=center style="width:125.8500pt;padding:6.0000pt 6.0000pt 6.0000pt 6.0000pt ;border-left:1.0000pt solid rgb(102,102,102);
mso-border-left-alt:0.7500pt solid rgb(102,102,102);border-right:1.0000pt solid rgb(102,102,102);mso-border-right-alt:0.7500pt solid rgb(102,102,102);
border-top:none;mso-border-top-alt:0.7500pt solid rgb(102,102,102);border-bottom:1.0000pt solid rgb(102,102,102);
mso-border-bottom-alt:0.7500pt solid rgb(102,102,102);">
                    <p class=MsoNormal style="margin-top:7.5000pt;margin-bottom:7.5000pt;"><b><span dir="LTR" style="font-family:Aptos;color:rgb(51,51,51);font-weight:bold;
font-size:12.0000pt;">CMND/CCCD s&#7889;</span></b><b><span style="font-family:Aptos;color:rgb(51,51,51);font-weight:bold;
font-size:12.0000pt;">
                                <o:p></o:p>
                            </span></b></p>
                </td>
                <td width=455 valign=center style="width:341.3500pt;padding:6.0000pt 6.0000pt 6.0000pt 6.0000pt ;border-left:none;
mso-border-left-alt:none;border-right:1.0000pt solid rgb(102,102,102);mso-border-right-alt:0.7500pt solid rgb(102,102,102);
border-top:none;mso-border-top-alt:0.7500pt solid rgb(102,102,102);border-bottom:1.0000pt solid rgb(102,102,102);
mso-border-bottom-alt:0.7500pt solid rgb(102,102,102);">
                    <p class=MsoNormal style="margin-top:7.5000pt;margin-bottom:7.5000pt;"><span dir="LTR"
                            style="font-family:Aptos;color:rgb(51,51,51);font-size:12.0000pt;">
                            <font face="Aptos">{{ $userIdNumber }} cấp ngày {{ $userIdIssueDate }} nơi cấp
                                {{ $userIdIssuePlace }}</font>
                        </span><span style="font-family:Aptos;color:rgb(51,51,51);font-size:12.0000pt;">
                            <o:p></o:p>
                        </span></p>
                </td>
            </tr>
            <tr>
                <td width=167 valign=center style="width:125.8500pt;padding:6.0000pt 6.0000pt 6.0000pt 6.0000pt ;border-left:1.0000pt solid rgb(102,102,102);
mso-border-left-alt:0.7500pt solid rgb(102,102,102);border-right:1.0000pt solid rgb(102,102,102);mso-border-right-alt:0.7500pt solid rgb(102,102,102);
border-top:none;mso-border-top-alt:0.7500pt solid rgb(102,102,102);border-bottom:1.0000pt solid rgb(102,102,102);
mso-border-bottom-alt:0.7500pt solid rgb(102,102,102);">
                    <p class=MsoNormal style="margin-top:7.5000pt;margin-bottom:7.5000pt;"><b><span dir="LTR" style="font-family:Aptos;color:rgb(51,51,51);font-weight:bold;
font-size:12.0000pt;">&#272;&#7883;a ch&#7881; th&#432;&#7901;ng tr&#250;</span></b><b><span style="font-family:Aptos;color:rgb(51,51,51);font-weight:bold;
font-size:12.0000pt;">
                                <o:p></o:p>
                            </span></b></p>
                </td>
                <td width=455 valign=center style="width:341.3500pt;padding:6.0000pt 6.0000pt 6.0000pt 6.0000pt ;border-left:none;
mso-border-left-alt:none;border-right:1.0000pt solid rgb(102,102,102);mso-border-right-alt:0.7500pt solid rgb(102,102,102);
border-top:none;mso-border-top-alt:0.7500pt solid rgb(102,102,102);border-bottom:1.0000pt solid rgb(102,102,102);
mso-border-bottom-alt:0.7500pt solid rgb(102,102,102);">
                    <p class=MsoNormal style="margin-top:7.5000pt;margin-bottom:7.5000pt;"><span dir="LTR"
                            style="font-family:Aptos;color:rgb(51,51,51);font-size:12.0000pt;">
                            <font face="Aptos">{{ $userPermanentAddress }}</font>
                        </span><span style="font-family:Aptos;color:rgb(51,51,51);font-size:12.0000pt;">
                            <o:p></o:p>
                        </span></p>
                </td>
            </tr>
            <tr>
                <td width=167 valign=center style="width:125.8500pt;padding:6.0000pt 6.0000pt 6.0000pt 6.0000pt ;border-left:1.0000pt solid rgb(102,102,102);
mso-border-left-alt:0.7500pt solid rgb(102,102,102);border-right:1.0000pt solid rgb(102,102,102);mso-border-right-alt:0.7500pt solid rgb(102,102,102);
border-top:none;mso-border-top-alt:0.7500pt solid rgb(102,102,102);border-bottom:1.0000pt solid rgb(102,102,102);
mso-border-bottom-alt:0.7500pt solid rgb(102,102,102);">
                    <p class=MsoNormal style="margin-top:7.5000pt;margin-bottom:7.5000pt;"><b><span dir="LTR" style="font-family:Aptos;color:rgb(51,51,51);font-weight:bold;
font-size:12.0000pt;">&#272;i&#7879;n tho&#7841;i</span></b><b><span style="font-family:Aptos;color:rgb(51,51,51);font-weight:bold;
font-size:12.0000pt;">
                                <o:p></o:p>
                            </span></b></p>
                </td>
                <td width=455 valign=center style="width:341.3500pt;padding:6.0000pt 6.0000pt 6.0000pt 6.0000pt ;border-left:none;
mso-border-left-alt:none;border-right:1.0000pt solid rgb(102,102,102);mso-border-right-alt:0.7500pt solid rgb(102,102,102);
border-top:none;mso-border-top-alt:0.7500pt solid rgb(102,102,102);border-bottom:1.0000pt solid rgb(102,102,102);
mso-border-bottom-alt:0.7500pt solid rgb(102,102,102);">
                    <p class=MsoNormal style="margin-top:7.5000pt;margin-bottom:7.5000pt;"><span dir="LTR"
                            style="font-family:Aptos;color:rgb(51,51,51);font-size:12.0000pt;">
                            <font face="Aptos">{{ $userPhone }}</font>
                        </span><span style="font-family:Aptos;color:rgb(51,51,51);font-size:12.0000pt;">
                            <o:p></o:p>
                        </span></p>
                </td>
            </tr>
        </table>
        <h2><b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(0,83,156);
font-weight:bold;font-size:18.0000pt;">&#272;I&#7872;U 1. &#272;&#7888;I T&#431;&#7906;NG H&#7906;P
                    &#272;&#7890;NG</span></b><b><span style="mso-spacerun:'yes';font-family:Aptos;color:rgb(0,83,156);
font-weight:bold;font-size:18.0000pt;">
                    <o:p></o:p>
                </span></b></h2>
        <p class=MsoNormal style="margin-top:14.0000pt;margin-bottom:0.0000pt;margin-left:36.0000pt;
text-indent:-18.0000pt;mso-list:l2 level1 lfo2;">
            <![if !supportLists]><span
                style="font-family:'Noto Sans Symbols';color:rgb(51,51,51);font-size:10.0000pt;"><span
                    style='mso-list:Ignore;'>&#9679;<span>&nbsp;</span></span></span>
            <![endif]><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">&#272;&#7883;a ch&#7881; thu&#234;: </span><b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-weight:bold;font-size:10.5000pt;">
                    <font face="Aptos">{{ $houseAddress }}</font>
                </span></b><span style="mso-spacerun:'yes';font-family:Arial;color:rgb(51,51,51);
font-size:10.5000pt;">
                <o:p></o:p>
            </span>
        </p>
        <p class=MsoNormal style="margin-top:0.0000pt;margin-bottom:0.0000pt;margin-left:36.0000pt;
text-indent:-18.0000pt;mso-list:l2 level1 lfo2;">
            <![if !supportLists]><span
                style="font-family:'Noto Sans Symbols';color:rgb(51,51,51);font-size:10.0000pt;"><span
                    style='mso-list:Ignore;'>&#9679;<span>&nbsp;</span></span></span>
            <![endif]><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">Di&#7879;n t&#237;ch: </span><b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-weight:bold;font-size:10.5000pt;">
                    <font face="Aptos">{{ $roomArea }} m&#178;</font>
                </span></b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">, g&#7891;m ph&#242;ng ng&#7911;, v&#7879; sinh, b&#7871;p (n&#7871;u c&#243;).</span><span
                style="mso-spacerun:'yes';font-family:Arial;color:rgb(51,51,51);
font-size:10.5000pt;">
                <o:p></o:p>
            </span>
        </p>
        <p class=MsoNormal style="margin-top:0.0000pt;margin-bottom:14.0000pt;margin-left:36.0000pt;
text-indent:-18.0000pt;mso-list:l2 level1 lfo2;">
            <![if !supportLists]><span
                style="font-family:'Noto Sans Symbols';color:rgb(51,51,51);font-size:10.0000pt;"><span
                    style='mso-list:Ignore;'>&#9679;<span>&nbsp;</span></span></span>
            <![endif]><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">M&#7909;c &#273;&#237;ch s&#7917; d&#7909;ng: </span><b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-weight:bold;font-size:10.5000pt;">
                    <font face="Aptos">{{ $rentalPurpose }}</font>
                </span></b><span style="mso-spacerun:'yes';font-family:Arial;color:rgb(51,51,51);
font-size:10.5000pt;">
                <o:p></o:p>
            </span>
        </p>
        <h2><b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(0,83,156);
font-weight:bold;font-size:18.0000pt;">&#272;I&#7872;U 2. TH&#7900;I H&#7840;N THU&#202;</span></b><b><span style="mso-spacerun:'yes';font-family:Aptos;color:rgb(0,83,156);
font-weight:bold;font-size:18.0000pt;">
                    <o:p></o:p>
                </span></b></h2>
        <p class=MsoNormal style="margin-top:14.0000pt;margin-bottom:0.0000pt;margin-left:36.0000pt;
text-indent:-18.0000pt;mso-list:l7 level1 lfo3;">
            <![if !supportLists]><span
                style="font-family:'Noto Sans Symbols';color:rgb(51,51,51);font-size:10.0000pt;"><span
                    style='mso-list:Ignore;'>&#9679;<span>&nbsp;</span></span></span>
            <![endif]><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">T&#7915; ng&#224;y </span><b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-weight:bold;font-size:10.5000pt;">
                    <font face="Aptos">{{ $startDate }}</font>
                </span></b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">&nbsp;&#273;&#7871;n ng&#224;y </span><b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-weight:bold;font-size:10.5000pt;">
                    <font face="Aptos">{{ $endDate }}</font>
                </span></b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">.</span><span style="mso-spacerun:'yes';font-family:Arial;color:rgb(51,51,51);
font-size:10.5000pt;">
                <o:p></o:p>
            </span>
        </p>
        <p class=MsoNormal style="margin-top:0.0000pt;margin-bottom:14.0000pt;margin-left:36.0000pt;
text-indent:-18.0000pt;mso-list:l7 level1 lfo3;">
            <![if !supportLists]><span
                style="font-family:'Noto Sans Symbols';color:rgb(51,51,51);font-size:10.0000pt;"><span
                    style='mso-list:Ignore;'>&#9679;<span>&nbsp;</span></span></span>
            <![endif]><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">Gia h&#7841;n: ph&#7843;i b&#225;o tr&#432;&#7899;c </span><b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-weight:bold;font-size:10.5000pt;">7</span></b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">&nbsp;ng&#224;y so v&#7899;i ng&#224;y k&#7871;t th&#250;c.</span><span style="mso-spacerun:'yes';font-family:Arial;color:rgb(51,51,51);
font-size:10.5000pt;">
                <o:p></o:p>
            </span>
        </p>
        <h2><b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(0,83,156);
font-weight:bold;font-size:18.0000pt;">&#272;I&#7872;U 3. GI&#193; & THANH TO&#193;N</span></b><b><span style="mso-spacerun:'yes';font-family:Aptos;color:rgb(0,83,156);
font-weight:bold;font-size:18.0000pt;">
                    <o:p></o:p>
                </span></b></h2>
        <p class=MsoNormal style="margin-top:14.0000pt;margin-bottom:0.0000pt;margin-left:36.0000pt;
text-indent:-18.0000pt;mso-list:l5 level1 lfo4;">
            <![if !supportLists]><span
                style="font-family:'Noto Sans Symbols';color:rgb(51,51,51);font-size:10.0000pt;"><span
                    style='mso-list:Ignore;'>&#9679;<span>&nbsp;</span></span></span>
            <![endif]><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">Gi&#225; thu&#234;: </span><b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-weight:bold;font-size:10.5000pt;">
                    <font face="Aptos">{{ number_format($totalPrice, 0, ',', '.') }} VN&#272;</font>
                </span></b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">&nbsp;(b&#7857;ng ch&#7919;: {{ $totalPriceInWords }})</span><span style="mso-spacerun:'yes';font-family:Arial;color:rgb(51,51,51);
font-size:10.5000pt;">
                <o:p></o:p>
            </span>
        </p>
        <p class=MsoNormal style="margin-top:0.0000pt;margin-bottom:0.0000pt;margin-left:36.0000pt;
text-indent:-18.0000pt;mso-list:l5 level1 lfo4;">
            <![if !supportLists]><span
                style="font-family:'Noto Sans Symbols';color:rgb(51,51,51);font-size:10.0000pt;"><span
                    style='mso-list:Ignore;'>&#9679;<span>&nbsp;</span></span></span>
            <![endif]><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">Thanh to&#225;n: H&#236;nh th&#7913;c: {{ $paymentMethod }}</span><span style="mso-spacerun:'yes';font-family:'Times New Roman';color:rgb(51,51,51);
font-size:10.5000pt;">
                <o:p></o:p>
            </span>
        </p>
        <p class=MsoNormal style="margin-top:0.0000pt;margin-bottom:14.0000pt;margin-left:36.0000pt;
text-indent:-18.0000pt;mso-list:l5 level1 lfo4;">
            <![if !supportLists]><span
                style="font-family:'Noto Sans Symbols';color:rgb(51,51,51);font-size:10.0000pt;"><span
                    style='mso-list:Ignore;'>&#9679;<span>&nbsp;</span></span></span>
            <![endif]><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">N&#7871;u chuy&#7875;n kho&#7843;n, TK B&#234;n
                A:</span>@if($paymentMethod == 'chuyển khoản' || $paymentMethod == 'Chuyển khoản qua VNPay' || $paymentMethod == 'vnpay')<span
                                    dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
                    font-size:10.5000pt;"><br></span><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
                    font-size:10.5000pt;">&nbsp;&nbsp;- Ch&#7911; TK: {{ $bankAccountOwner }}&nbsp;&nbsp;- S&#7889; TK:
                                    {{ $bankAccountNumber }}</span><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
                    font-size:10.5000pt;"><br></span><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
                font-size:10.5000pt;">&nbsp;&nbsp;- Ng&#226;n h&#224;ng: {{ $bankName }}</span>@endif<span style="mso-spacerun:'yes';font-family:'Times New Roman';color:rgb(51,51,51);
font-size:10.5000pt;">
                <o:p></o:p>
            </span>
        </p>
        <h2><b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(0,83,156);
font-weight:bold;font-size:18.0000pt;">&#272;I&#7872;U 4. QUY&#7872;N & NGH&#296;A V&#7908;</span></b><b><span style="mso-spacerun:'yes';font-family:Aptos;color:rgb(0,83,156);
font-weight:bold;font-size:18.0000pt;">
                    <o:p></o:p>
                </span></b></h2>
        <h3><b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-weight:bold;font-size:13.5000pt;">4.1. B&#234;n A</span></b><b><span style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-weight:bold;font-size:13.5000pt;">
                    <o:p></o:p>
                </span></b></h3>
        <p class=MsoNormal style="margin-top:14.0000pt;margin-bottom:0.0000pt;margin-left:36.0000pt;
text-indent:-18.0000pt;mso-list:l3 level1 lfo5;">
            <![if !supportLists]><span
                style="font-family:'Noto Sans Symbols';color:rgb(51,51,51);font-size:10.0000pt;"><span
                    style='mso-list:Ignore;'>&#9679;<span>&nbsp;</span></span></span>
            <![endif]><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">B&#224;n giao &#273;i&#7879;n, n&#432;&#7899;c, internet v&#224; trang thi&#7871;t b&#7883;
                (n&#7871;u c&#243;).</span><span style="mso-spacerun:'yes';font-family:'Times New Roman';color:rgb(51,51,51);
font-size:10.5000pt;">
                <o:p></o:p>
            </span>
        </p>
        <p class=MsoNormal style="margin-top:0.0000pt;margin-bottom:0.0000pt;margin-left:36.0000pt;
text-indent:-18.0000pt;mso-list:l3 level1 lfo5;">
            <![if !supportLists]><span
                style="font-family:'Noto Sans Symbols';color:rgb(51,51,51);font-size:10.0000pt;"><span
                    style='mso-list:Ignore;'>&#9679;<span>&nbsp;</span></span></span>
            <![endif]><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">B&#7843;o tr&#236; k&#7871;t c&#7845;u, h&#7879; th&#7889;ng chung.</span><span style="mso-spacerun:'yes';font-family:'Times New Roman';color:rgb(51,51,51);
font-size:10.5000pt;">
                <o:p></o:p>
            </span>
        </p>
        <p class=MsoNormal style="margin-top:0.0000pt;margin-bottom:14.0000pt;margin-left:36.0000pt;
text-indent:-18.0000pt;mso-list:l3 level1 lfo5;">
            <![if !supportLists]><span
                style="font-family:'Noto Sans Symbols';color:rgb(51,51,51);font-size:10.0000pt;"><span
                    style='mso-list:Ignore;'>&#9679;<span>&nbsp;</span></span></span>
            <![endif]><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">Y&#234;u c&#7847;u B&#234;n B thanh to&#225;n &#273;&#250;ng h&#7841;n.</span><span style="mso-spacerun:'yes';font-family:'Times New Roman';color:rgb(51,51,51);
font-size:10.5000pt;">
                <o:p></o:p>
            </span>
        </p>
        <h3><b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-weight:bold;font-size:13.5000pt;">4.2. B&#234;n B</span></b><b><span style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-weight:bold;font-size:13.5000pt;">
                    <o:p></o:p>
                </span></b></h3>
        <p class=MsoNormal style="margin-top:14.0000pt;margin-bottom:0.0000pt;margin-left:36.0000pt;
text-indent:-18.0000pt;mso-list:l6 level1 lfo6;">
            <![if !supportLists]><span
                style="font-family:'Noto Sans Symbols';color:rgb(51,51,51);font-size:10.0000pt;"><span
                    style='mso-list:Ignore;'>&#9679;<span>&nbsp;</span></span></span>
            <![endif]><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">Thanh to&#225;n &#273;&#7847;y &#273;&#7911;, &#273;&#250;ng h&#7841;n.</span><span style="mso-spacerun:'yes';font-family:'Times New Roman';color:rgb(51,51,51);
font-size:10.5000pt;">
                <o:p></o:p>
            </span>
        </p>
        <p class=MsoNormal style="margin-top:0.0000pt;margin-bottom:0.0000pt;margin-left:36.0000pt;
text-indent:-18.0000pt;mso-list:l6 level1 lfo6;">
            <![if !supportLists]><span
                style="font-family:'Noto Sans Symbols';color:rgb(51,51,51);font-size:10.0000pt;"><span
                    style='mso-list:Ignore;'>&#9679;<span>&nbsp;</span></span></span>
            <![endif]><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">S&#7917; d&#7909;ng, gi&#7919; g&#236;n t&#224;i s&#7843;n thu&#234;.</span><span style="mso-spacerun:'yes';font-family:'Times New Roman';color:rgb(51,51,51);
font-size:10.5000pt;">
                <o:p></o:p>
            </span>
        </p>
        <p class=MsoNormal style="margin-top:0.0000pt;margin-bottom:0.0000pt;margin-left:36.0000pt;
text-indent:-18.0000pt;mso-list:l6 level1 lfo6;">
            <![if !supportLists]><span
                style="font-family:'Noto Sans Symbols';color:rgb(51,51,51);font-size:10.0000pt;"><span
                    style='mso-list:Ignore;'>&#9679;<span>&nbsp;</span></span></span>
            <![endif]><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">Kh&#244;ng t&#7921; &#253; s&#7917;a ch&#7919;a ki&#7871;n tr&#250;c, thay &#273;&#7893;i
                k&#7871;t c&#7845;u.</span><span style="mso-spacerun:'yes';font-family:'Times New Roman';color:rgb(51,51,51);
font-size:10.5000pt;">
                <o:p></o:p>
            </span>
        </p>
        <p class=MsoNormal style="margin-top:0.0000pt;margin-bottom:14.0000pt;margin-left:36.0000pt;
text-indent:-18.0000pt;mso-list:l6 level1 lfo6;">
            <![if !supportLists]><span
                style="font-family:'Noto Sans Symbols';color:rgb(51,51,51);font-size:10.0000pt;"><span
                    style='mso-list:Ignore;'>&#9679;<span>&nbsp;</span></span></span>
            <![endif]><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">Tu&#226;n th&#7911; n&#7897;i quy tr&#7885;, an ninh tr&#7853;t t&#7921;.</span><span style="mso-spacerun:'yes';font-family:'Times New Roman';color:rgb(51,51,51);
font-size:10.5000pt;">
                <o:p></o:p>
            </span>
        </p>
        <h2><b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(0,83,156);
font-weight:bold;font-size:18.0000pt;">&#272;I&#7872;U 5. CH&#7844;M D&#7912;T H&#7906;P
                    &#272;&#7890;NG</span></b><b><span style="mso-spacerun:'yes';font-family:Aptos;color:rgb(0,83,156);
font-weight:bold;font-size:18.0000pt;">
                    <o:p></o:p>
                </span></b></h2>
        <p class=MsoNormal style="margin-top:14.0000pt;margin-bottom:0.0000pt;margin-left:36.0000pt;
text-indent:-18.0000pt;mso-list:l4 level1 lfo7;">
            <![if !supportLists]><span
                style="font-family:'Noto Sans Symbols';color:rgb(51,51,51);font-size:10.0000pt;"><span
                    style='mso-list:Ignore;'>&#9679;<span>&nbsp;</span></span></span>
            <![endif]><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">T&#7921; &#273;&#7897;ng k&#7871;t th&#250;c khi h&#7871;t h&#7841;n, n&#7871;u kh&#244;ng gia
                h&#7841;n.</span><span style="mso-spacerun:'yes';font-family:'Times New Roman';color:rgb(51,51,51);
font-size:10.5000pt;">
                <o:p></o:p>
            </span>
        </p>
        <p class=MsoNormal style="margin-top:0.0000pt;margin-bottom:14.0000pt;margin-left:36.0000pt;
text-indent:-18.0000pt;mso-list:l4 level1 lfo7;">
            <![if !supportLists]><span
                style="font-family:'Noto Sans Symbols';color:rgb(51,51,51);font-size:10.0000pt;"><span
                    style='mso-list:Ignore;'>&#9679;<span>&nbsp;</span></span></span>
            <![endif]><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">Vi ph&#7841;m h&#7907;p &#273;&#7891;ng, b&#234;n kia c&#243; quy&#7873;n ch&#7845;m d&#7913;t
                &#273;&#417;n ph&#432;&#417;ng v&#224; b&#7891;i th&#432;&#7901;ng.</span><span style="mso-spacerun:'yes';font-family:'Times New Roman';color:rgb(51,51,51);
font-size:10.5000pt;">
                <o:p></o:p>
            </span>
        </p>
        <h2><b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(0,83,156);
font-weight:bold;font-size:18.0000pt;">&#272;I&#7872;U 6. GI&#7842;I QUY&#7870;T TRANH CH&#7844;P</span></b><b><span
                    style="mso-spacerun:'yes';font-family:Aptos;color:rgb(0,83,156);
font-weight:bold;font-size:18.0000pt;">
                    <o:p></o:p>
                </span></b></h2>
        <p class=MsoNormal style="margin-top:0.0000pt;margin-right:0.0000pt;margin-bottom:0.0000pt;
margin-left:0.0000pt;text-indent:0.0000pt;padding:0pt 0pt 0pt 0pt ;
mso-pagination:widow-orphan;text-align:left;"><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-style:normal;font-variant:normal;font-size:10.5000pt;">Th&#7887;a thu&#7853;n – h&#242;a gi&#7843;i – n&#7871;u
                kh&#244;ng &#273;&#432;&#7907;c gi&#7843;i quy&#7871;t, &#273;&#432;a ra T&#242;a &#225;n nh&#226;n
                d&#226;n n&#417;i c&#243; b&#7845;t &#273;&#7897;ng s&#7843;n.</span><span style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-style:normal;font-variant:normal;font-size:10.5000pt;">
                <o:p></o:p>
            </span></p>
        <h2><b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(0,83,156);
font-weight:bold;font-size:18.0000pt;">&#272;I&#7872;U 7. &#272;I&#7872;U KHO&#7842;N THI H&#192;NH</span></b><b><span
                    style="mso-spacerun:'yes';font-family:Aptos;color:rgb(0,83,156);
font-weight:bold;font-size:18.0000pt;">
                    <o:p></o:p>
                </span></b></h2>
        <p class=MsoNormal style="margin-top:14.0000pt;margin-bottom:0.0000pt;margin-left:36.0000pt;
text-indent:-18.0000pt;mso-list:l1 level1 lfo8;">
            <![if !supportLists]><span
                style="font-family:'Noto Sans Symbols';color:rgb(51,51,51);font-size:10.0000pt;"><span
                    style='mso-list:Ignore;'>&#9679;<span>&nbsp;</span></span></span>
            <![endif]><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">H&#7907;p &#273;&#7891;ng c&#243; hi&#7879;u l&#7921;c k&#7875; t&#7915; ng&#224;y
                k&#253;.</span><span style="mso-spacerun:'yes';font-family:'Times New Roman';color:rgb(51,51,51);
font-size:10.5000pt;">
                <o:p></o:p>
            </span>
        </p>
        <p class=MsoNormal style="margin-top:0.0000pt;margin-bottom:14.0000pt;margin-left:36.0000pt;
text-indent:-18.0000pt;mso-list:l1 level1 lfo8;">
            <![if !supportLists]><span
                style="font-family:'Noto Sans Symbols';color:rgb(51,51,51);font-size:10.0000pt;"><span
                    style='mso-list:Ignore;'>&#9679;<span>&nbsp;</span></span></span>
            <![endif]><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">L&#7853;p th&#224;nh 02 b&#7843;n, m&#7895;i b&#234;n gi&#7919; 01 b&#7843;n c&#243; gi&#225;
                tr&#7883; ph&#225;p l&#253; nh&#432; nhau.</span>
        </p>
    </div>
    <span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-weight:bold;font-size:10.5000pt;"><br clear=all
            style='page-break-before:auto;mso-break-type:section-break'></span>
    <div class="Section1">
        <table style="width: 100%; border-collapse: collapse; margin-top: 14.0000pt;">
            <tr>
                <!-- Bên A - Bên trái -->
                <td style="width: 50%; vertical-align: top; padding-right: 20px; text-align: center;">
                    <p class=MsoNormal style="margin-top:0.0000pt;margin-bottom:14.0000pt;text-align:center;"><b><span
                                dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-weight:bold;font-size:10.5000pt;">B&#202;N A (&#272;&#7841;i di&#7879;n C&#244;ng ty)</span></b><span dir="LTR"
                            style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;"><br></span><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">(K&#253; & ghi r&#245; h&#7885; t&#234;n, ch&#7913;c v&#7909;)</span><span style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">
                            <o:p></o:p>
                        </span></p>
                    @if($companyRepresentativeSignature)
                        <p class=MsoNormal style="margin-top:0.0000pt;margin-bottom:14.0000pt;text-align:center;">
                            <img src="{{ $companyRepresentativeSignature }}" alt="Chữ ký người đại diện"
                                style="max-width: 200px; max-height: 80px; object-fit: contain;" />
                        </p>
                    @else
                        <p class=MsoNormal style="margin-top:45.0000pt;margin-bottom:14.0000pt;text-align:center;">
                            <span style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
                        font-size:10.5000pt;">
                                <o:p></o:p>
                            </span>
                        </p>
                    @endif
                    <p class=MsoNormal style="margin-top:0.0000pt;margin-bottom:0.0000pt;text-align:center;"><b><span
                                dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-weight:bold;font-size:10.5000pt;">{{ $companyRepresentativeName }}</span></b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;"><br></span><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">{{ $companyRepresentativePosition }}</span></p>
                </td>
                <!-- Bên B - Bên phải -->
                <td style="width: 50%; vertical-align: top; padding-left: 20px; text-align: center;">
                    <p class=MsoNormal style="margin-top:0.0000pt;margin-bottom:14.0000pt;text-align:center;"><b><span
                                dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-weight:bold;font-size:10.5000pt;">B&#202;N B (Ng&#432;&#7901;i Thu&#234;)</span></b><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;"><br></span><span dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">(K&#253; & ghi r&#245; h&#7885; t&#234;n)</span></p>
                    @if($userSignature)
                        <p class=MsoNormal style="margin-top:0.0000pt;margin-bottom:14.0000pt;text-align:center;">
                            <img src="{{ $userSignature }}" alt="Chữ ký"
                                style="max-width: 200px; max-height: 80px; object-fit: contain;" />
                        </p>
                    @else
                                            <p class=MsoNormal style="margin-top:45.0000pt;margin-bottom:14.0000pt;text-align:center;">
                                                <span style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
                        font-size:10.5000pt;">
                                                    <o:p></o:p>
                                                </span>
                                            </p>
                    @endif
                    <p class=MsoNormal style="margin-top:0.0000pt;margin-bottom:14.0000pt;text-align:center;"><b><span
                                dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-weight:bold;font-size:10.5000pt;">{{ $userName }}</span></b></p>
                    @if($signedAt)
                                            <p class=MsoNormal style="margin-top:0.0000pt;margin-bottom:0.0000pt;text-align:center;"><span
                                                    dir="LTR" style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
                        font-size:10.5000pt;">Đã ký ngày: {{ $signedAt }}</span></p>
                    @endif
                </td>
            </tr>
        </table>
    </div>
    <span style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;"><br clear=all style='page-break-before:auto;mso-break-type:section-break'></span>
    <div class="Section2">
        <p class=MsoNormal style="margin-top:14.0000pt;margin-bottom:45.0000pt;"><span style="mso-spacerun:'yes';font-family:Aptos;color:rgb(51,51,51);
font-size:10.5000pt;">
                <o:p></o:p>
            </span></p>
    </div><!--EndFragment-->
</body>

</html>