<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Room extends Model
{
    protected $fillable = [
        'house_id',
        'room_number',
        'floor',
        'price_per_day',
        'status',
        'area',
        'amenities',
        'images',
        'tenant_name',
        'tenant_id',
        'rental_start_date',
        'rental_end_date',
    ];

    protected function casts(): array
    {
        return [
            'price_per_day' => 'decimal:2',
            'area' => 'decimal:2',
            'amenities' => 'array',
            'images' => 'array',
            'rental_start_date' => 'date',
            'rental_end_date' => 'date',
        ];
    }

    /**
     * Get the house that owns the room.
     */
    public function house(): BelongsTo
    {
        return $this->belongsTo(House::class);
    }

    /**
     * Get the bookings for the room.
     */
    public function bookings(): HasMany
    {
        return $this->hasMany(Booking::class);
    }

    /**
     * Get active booking for the room.
     */
    public function activeBooking(): HasMany
    {
        return $this->hasMany(Booking::class)->where('status', 'active');
    }

    /**
     * Get the tenant (user) currently renting the room.
     */
    public function tenant(): BelongsTo
    {
        return $this->belongsTo(User::class, 'tenant_id');
    }

    /**
     * Check if room is available for booking in a date range
     * Room is NOT available only if there are PAID bookings that overlap with the requested date range
     * Pending or failed bookings are ignored
     */
    public function isAvailableForDates($startDate, $endDate): bool
    {
        // Check for overlapping PAID bookings only
        // Ignore pending/failed bookings
        $overlappingBookings = $this->bookings()
            ->where('payment_status', 'paid')
            ->where(function ($query) use ($startDate, $endDate) {
                // Booking overlaps if:
                // - Booking starts before or on requested end date
                // - AND booking ends after or on requested start date
                $query->where('start_date', '<=', $endDate)
                      ->where('end_date', '>=', $startDate);
            })
            ->exists();

        return !$overlappingBookings;
    }

    /**
     * Get status for a specific date range
     * Returns 'occupied' only if there are PAID bookings in that date range, 'available' otherwise
     * Pending or failed bookings are ignored
     */
    public function getStatusForDates($startDate, $endDate): string
    {
        $hasBooking = $this->bookings()
            ->where('payment_status', 'paid')
            ->where(function ($query) use ($startDate, $endDate) {
                $query->where('start_date', '<=', $endDate)
                      ->where('end_date', '>=', $startDate);
            })
            ->exists();

        return $hasBooking ? 'occupied' : 'available';
    }

    /**
     * Get effective status based on bookings
     * Room is occupied only if there's a paid booking that has reached check-in date
     */
    public function getEffectiveStatus(): string
    {
        $activeBooking = $this->bookings()
            ->where('payment_status', 'paid')
            ->where('start_date', '<=', now()->toDateString())
            ->where('end_date', '>=', now()->toDateString())
            ->first();

        return $activeBooking ? 'occupied' : 'available';
    }
}
